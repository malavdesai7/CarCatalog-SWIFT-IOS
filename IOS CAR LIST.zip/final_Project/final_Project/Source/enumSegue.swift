//
//  enumSegue.swift
//  final_Project
//
//  Created by english on 2023-04-04.
//

import Foundation

enum Segue {
    
    static let toSecondViewController = "toSecondViewController"
    
    static let toThirdViewController = "toThirdViewController"
    
    static let toForthViewController = "toForthViewController"
    
    static let toForthViewControllerUpdating = "toForthViewControllerUpdating"
    
}

