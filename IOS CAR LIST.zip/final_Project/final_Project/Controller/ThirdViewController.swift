//
//  ThirdViewController.swift
//  final_Project
//
//  Created by english on 2023-03-30.
//

import UIKit

class ThirdViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UIPickerViewDelegate, UIPickerViewDataSource {
    
    
    public var loggedUser : UserModel?
    private var selectedCar : CarModel?
    private var carList: [CarModel]?
    
    var pickerData: [String] = [String]()
    var selectedType: String = ""
    
    
    @IBOutlet weak var lblUsername: UILabel!
    
    @IBOutlet weak var tableview: UITableView!
    
    @IBOutlet weak var pickerview: UIPickerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableview.register(UINib(nibName: "CarDataTableViewCell", bundle: nil), forCellReuseIdentifier: "CarDataTableViewCell")
        
        lblUsername.text = "Hello \(loggedUser!.name)"
        
        CarProvider.generateCarMockData()
        
        tableview.delegate = self
        tableview.dataSource = self
        
        self.pickerview.delegate = self
        self.pickerview.dataSource = self
        
        pickerData = ["SUV", "Convertible", "Sedan", "Wagon", "Pickup"]
        
        carList = CarProvider.all

    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedType = pickerData[row]
        
        carList = CarProvider.all.filter { $0.type!.contains(selectedType)
        }
        
        tableview.reloadData()
    }

    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CarDataTableViewCell", for: indexPath) as! CarDataTableViewCell
 
        if indexPath.row < carList!.count {
            cell.setCellContent(car: carList![indexPath.row])
            }
            
            return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return carList!.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.selectedCar = carList![indexPath.row]

        self.performSegue(withIdentifier: Segue.toForthViewControllerUpdating, sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == Segue.toForthViewControllerUpdating {
            
            let forthViewController = segue.destination as! FourthViewController
            
            forthViewController.selectedCar = self.selectedCar
            
        }
        
    }
    
    @IBAction func btnAdd(_ sender: Any) {
        
    }
    
   
    @IBAction func btnRefresh(_ sender: Any) {
        tableview.reloadData()
    }
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
