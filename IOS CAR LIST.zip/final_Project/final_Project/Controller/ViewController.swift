//
//  ViewController.swift
//  final_Project
//
//  Created by english on 2023-03-30.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var rememberMe: UISwitch!
    
    private var loggedUser : UserModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        UserProvider.generateMockData()
    }
    
    @IBAction func btnRememberMe(_ sender: Any) {
        if rememberMe.isOn {
                print("ON")
            }
            else {
                print ("OFF")
            }
    }
    
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        if identifier == Segue.toSecondViewController{
            return true
        }
        
        guard let username = txtUsername.text, let password = txtPassword.text else{
            print("Something is wrong.. try again!!!")
            return false
        }
        
        if let user = UserProvider.find(id: nil, username: username){
            
            if user.password == password {
                self.loggedUser = user
                return true
            } else {
                print("Wrong password.. try again!!!")
                return false
            }
            
        } else {
            print("User not found.. create new account!!")
            return false
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == Segue.toThirdViewController{
            
            let thirdViewController = segue.destination as! ThirdViewController
            
            thirdViewController.loggedUser = self.loggedUser
        }
    }
}

