//
//  FourthViewController.swift
//  final_Project
//
//  Created by english on 2023-03-30.
//

import UIKit

class FourthViewController: UIViewController {
    
    var selectedCar : CarModel?
    
    @IBOutlet weak var lblid: UILabel!
    @IBOutlet weak var txtId: UITextField!
    @IBOutlet weak var txtCompany: UITextField!
    @IBOutlet weak var txtType: UITextField!
    @IBOutlet weak var txtModel: UITextField!
    @IBOutlet weak var txtYear: UITextField!
    @IBOutlet weak var txtCondition: UITextField!
    @IBOutlet weak var txtPrice: UITextField!
    @IBOutlet weak var btnDelete: UIButton!
    
    @IBAction func btnSave(_ sender: Any) {
        
        
        guard let id = Int(txtId.text!), let company = txtCompany.text, let type = txtType.text, let model = txtModel.text, let year = Int(txtYear.text!), let condition = txtCondition.text, let price = Double(txtPrice.text!), !txtId.text!.isEmpty, !txtPrice.text!.isEmpty, !company.isEmpty, !type.isEmpty, !model.isEmpty, !txtYear.text!.isEmpty, !condition.isEmpty else {
            Toast.ok(view: self, title: "Ooops!", message: "Please, make sure all fields are filled with information!", handler: nil)
            return
        }

        
        if self.selectedCar == nil {
            
            if let car = CarProvider.find(id: nil){
                Toast.ok(view: self, title: "Ooops", message: "The id \(id) is already in use by \(car.model!)", handler: nil)
                return
            }

            
            
            let newCar = CarModel(id: id, year: year, company: company, model: model, type: type, price: price, condition: condition)
            
            CarProvider.insert(newCar: newCar)
            
        } else {
            
            self.selectedCar!.company = company
            self.selectedCar!.type = type
            self.selectedCar!.model = model
            self.selectedCar!.year = year
            self.selectedCar!.condition = condition
            self.selectedCar!.price = price
            
            let _ = CarProvider.update(car: self.selectedCar!)
            
        }

        navigationController?.popViewController(animated: true)

    }
    
    
    @IBAction func btnDelete(_ sender: Any) {
        
        let _ = CarProvider.delete(car: self.selectedCar!)
        
        navigationController!.popViewController(animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if self.selectedCar == nil {
            title = "New car"
            
            btnDelete.isHidden = true
            
        } else {
            title = "Updating car"
            
            txtId.isHidden = true
            lblid.isHidden = true
            
            txtId.text  = "\(self.selectedCar!.id!)"
            txtCompany.text = self.selectedCar!.company
            txtType.text = self.selectedCar!.type
            txtModel.text = self.selectedCar!.model
            txtYear.text = "\(self.selectedCar!.year!)"
            txtCondition.text = self.selectedCar!.condition
            txtPrice.text = "\(self.selectedCar!.price!)"
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
