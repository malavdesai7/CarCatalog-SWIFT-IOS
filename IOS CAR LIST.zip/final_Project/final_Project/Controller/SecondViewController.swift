//
//  SecondViewController.swift
//  final_Project
//
//  Created by english on 2023-03-30.
//

import UIKit

class SecondViewController: UIViewController {

    
    @IBOutlet weak var txtFullName: UITextField!
    
    @IBOutlet weak var txtUsername: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var btnPasswordVisible: UIButton!
    
    @IBAction func btnPasswordVisibleTouchUp(_ sender: Any) {
        
        if txtPassword.isSecureTextEntry{
            btnPasswordVisible.setImage(UIImage(systemName: "eye.slash"), for: UIControl.State.normal)
        }else{
            btnPasswordVisible.setImage(UIImage(systemName: "eye"), for: UIControl.State.normal)
        }
        
        txtPassword.isSecureTextEntry.toggle()
    }
    
    @IBAction func btnSignUp(_ sender: Any) {
        
        guard let username = txtUsername.text, let fullname = txtFullName.text, let password = txtPassword.text else {
            Toast.ok(view: self, title: "Ooops!", message: "Something is wrong!", handler: nil)
            return
        }
        
        if username.isEmpty {
            Toast.ok(view: self, title: "Ooops!", message: "Please, enter a valid username.", handler: { action in
                self.txtUsername.becomeFirstResponder()  // set the focus
            })
            return
            
        }

        if fullname.isEmpty {
            Toast.ok(view: self, title: "Ooops!", message: "Please, enter your full name.", handler: { action in
                self.txtFullName.becomeFirstResponder()
            })
            return
        }
        
        if password.isEmpty {
            Toast.ok(view: self, title: "Ooops!", message: "Please, enter a secure password.", handler: { action in
                self.txtPassword.becomeFirstResponder()
            })
            return
        }
        
        if let user = UserProvider.find(id: nil, username: username){
            Toast.ok(view: self, title: "Ooops!", message: "The username \(username) is already register for \(user.name).", handler: nil)
            txtPassword.becomeFirstResponder()
            return
        }
        
        
        let newUser = UserModel(name: fullname, username: username, password: password)
        UserProvider.insert(newUser: newUser)
        

        navigationController?.popViewController(animated: true)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
