//
//  UserProvider.swift
//  final_Project
//
//  Created by english on 2023-04-04.
//

import Foundation

class UserProvider{

    
    static var all : [UserModel] = []
    
    static func insert( newUser : UserModel ){
        newUser.id = UserModel.getNextId()
        UserProvider.all.append(newUser)
    }

    static func find( id : Int? = nil, username : String? = nil) -> UserModel? {
        
        if id != nil {
            
            for user in UserProvider.all{
                if user.id == id {
                    return user
                }
            }
            
        } else {

            if username != nil {
                for user in UserProvider.all{
                    if user.username.lowercased() == username!.lowercased() {
                        return user
                    }
                }
            } 
        }
        
        return nil
    }

    static func generateMockData() {
        
        let admin = UserModel(name: "Administrator", username: "admin", password: "admin")
        insert(newUser: admin)
       
        let user = UserModel(name: "Pratham", username: "pratham", password: "1234")
        insert(newUser: user)

    }
   
}
