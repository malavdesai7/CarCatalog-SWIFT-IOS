//
//  CarProvider.swift
//  final_Project
//
//  Created by english on 2023-04-11.
//

import Foundation

class CarProvider{
    
    static var all : [CarModel] = []
    
    static func insert( newCar : CarModel ){
        CarProvider.all.append(newCar)
    }
    
    static func update( car : CarModel ) -> Bool {
        
        for (index, currentCar) in CarProvider.all.enumerated() {
            if currentCar.id == car.id {
                CarProvider.all[index] = car
                return true
            }
        }
        return false
    }

    static func delete( car : CarModel ) -> Bool {
        
        for (index, currentCar) in CarProvider.all.enumerated() {
            if currentCar.id == car.id {
                CarProvider.all.remove(at: index)
                return true
            }
        }
        return false
    }

    static func find( id : Int? = nil) -> CarModel? {
        
        if id != nil {
            
            for car in CarProvider.all{
                if car.id == id {
                    return car
                }
            }
            
        }
        
        return nil
    }
    
    static func generateCarMockData(){
        
        let car1 = CarModel(id: 1001, year: 2008, company: "Buick", model: "Enclave", type: "SUV", price: 6000, condition: "Average")
        
        let car2 = CarModel(id: 1002, year: 2006, company: "MINI", model: "Convertible", type: "Convertible", price: 5699, condition: "Good")
        
        let car3 = CarModel(id: 1003, year: 1999, company: "Ford", model: "Taurus", type: "Sedan, Wagon", price: 4100, condition: "Bad")
        
        let car4 = CarModel(id: 1004, year: 2020, company: "Volvo", model: "XC60", type: "SUV", price: 15000, condition: "New")
        
        let car5 = CarModel(id: 1005, year: 2006, company: "HUMMER", model: "H2", type: "SUV, Pickup", price: 6000, condition: "Good")
        
        let car6 = CarModel(id: 1006, year: 2016, company: "GMC", model: "Sierra 1500 Crew Cab", type: "Pickup", price: 8000, condition: "Very Good")
        
        let car7 = CarModel(id: 1007, year: 2008, company: "GMC", model: "Canyon Crew Cab", type: "Pickup", price: 5000, condition: "Average")
        
        let car8 = CarModel(id: 1008, year: 2016, company: "Subaru", model: "Outback", type: "SUV", price: 12000, condition: "Good")
        
        let car9 = CarModel(id: 1009, year: 2010, company: "Mitsubishi", model: "Outlander", type: "SUV", price: 8940, condition: "Bad")
        
        let car10 = CarModel(id: 1010, year: 2018, company: "Tesla", model: "S8", type: "SUV", price: 16000, condition: "Very good")
        
        insert(newCar: car1)
        insert(newCar: car2)
        insert(newCar: car3)
        insert(newCar: car4)
        insert(newCar: car5)
        insert(newCar: car6)
        insert(newCar: car7)
        insert(newCar: car8)
        insert(newCar: car9)
        insert(newCar: car10)
    }
}
