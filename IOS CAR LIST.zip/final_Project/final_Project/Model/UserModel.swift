//
//  UserModel.swift
//  final_Project
//
//  Created by english on 2023-04-04.
//

import Foundation

class UserModel {
    
    static private var generatorId : Int = 0
    
    public var id : Int = 0
    
    public var name : String
    public var username : String
    public var password : String

    init(name : String, username : String, password : String) {
        self.name = name
        self.username = username
        self.password = password
    }
    
    static func getNextId() -> Int {
        UserModel.generatorId += 1
        return UserModel.generatorId
    }
}
