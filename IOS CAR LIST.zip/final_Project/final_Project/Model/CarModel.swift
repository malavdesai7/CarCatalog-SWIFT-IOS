//
//  CarModel.swift
//  final_Project
//
//  Created by english on 2023-04-11.
//

import Foundation

class CarModel {
    
    var id : Int?
    
    var year : Int?
    
    var company : String?
    
    var model : String?
    
    var type : String?
    
    var price : Double?
    
    var condition : String?
    
    init (id : Int?, year : Int?, company : String, model : String?, type : String?, price : Double?, condition : String?){
        
        self.id = id
        self.year = year
        self.company = company
        self.model = model
        self.type = type
        self.price = price
        self.condition = condition
    }
    
}
