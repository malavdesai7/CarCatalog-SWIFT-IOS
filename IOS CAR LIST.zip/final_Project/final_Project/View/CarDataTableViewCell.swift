//
//  carDataTableViewCell.swift
//  final_Project
//
//  Created by english on 2023-04-11.
//

import UIKit

class CarDataTableViewCell: UITableViewCell {
    
    @IBOutlet weak var type: UILabel!
    
    @IBOutlet weak var company: UILabel!
    
    @IBOutlet weak var year: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    public func setCellContent ( car : CarModel){
        
        type.text = car.type
        company.text = car.company
        year.text = "\(car.year!)"
    }
    
}
